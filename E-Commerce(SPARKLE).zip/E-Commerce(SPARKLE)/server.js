const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Connect to MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'your_mysql_password',
  database: 'sparkle_store'
});

db.connect(err => {
  if (err) {
    console.error('Database connection failed:', err);
    return;
  }
  console.log('Connected to MySQL');
});

// Signup API
app.post('/signup', (req, res) => {
  const { name, email, password } = req.body;
  const sql = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
  db.query(sql, [name, email, password], (err, result) => {
    if (err) {
      return res.status(500).send('Signup failed: ' + err.message);
    }
    res.send('Signup successful');
  });
});

// Order API
app.post('/order', (req, res) => {
  const { user_email, total } = req.body;
  const sql = 'INSERT INTO orders (user_email, total) VALUES (?, ?)';
  db.query(sql, [user_email, total], (err, result) => {
    if (err) {
      return res.status(500).send('Order failed: ' + err.message);
    }
    res.send('Order placed successfully');
  });
});

// Start server
app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
